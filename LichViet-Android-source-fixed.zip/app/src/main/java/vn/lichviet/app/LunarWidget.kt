package vn.lichviet.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.widget.RemoteViews
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.floor

class LunarWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> updateOne(context, manager, id) }
    }
    override fun onReceive(context: Context, intent: android.content.Intent) {
        super.onReceive(context, intent)
        if (intent.action == IntentActions.DATE || intent.action == IntentActions.TIMEZONE ||
            intent.action == IntentActions.BOOT) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(android.content.ComponentName(context, LunarWidget::class.java))
            onUpdate(context, mgr, ids)
        }
    }
    private fun updateOne(c: Context, m: AppWidgetManager, id: Int) {
        val now = Calendar.getInstance(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"))
        val d = now.get(Calendar.DAY_OF_MONTH)
        val month = now.get(Calendar.MONTH) + 1
        val year = now.get(Calendar.YEAR)
        val (ld, lm, ly, leap) = lunar(d, month, year)
        val weekday = listOf("Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy")[now.get(Calendar.DAY_OF_WEEK)-1]
        val views = RemoteViews(c.packageName, R.layout.widget_lunar)
        views.setTextViewText(R.id.solar_day, "%02d".format(d))
        views.setTextViewText(R.id.lunar_line, "Âm lịch: %02d/%02d/%04d%s".format(ld, lm, ly, if (leap) " (nhuận)" else ""))
        views.setTextViewText(R.id.weekday_line, "$weekday  •  Tháng $month/$year")
        m.updateAppWidget(id, views)
    }
    private object IntentActions {
        const val DATE = "android.intent.action.DATE_CHANGED"
        const val TIMEZONE = "android.intent.action.TIMEZONE_CHANGED"
        const val BOOT = "android.intent.action.BOOT_COMPLETED"
    }
    // Vietnamese lunar calendar conversion (UTC+7), based on the standard astronomical new-moon method.
    private fun jd(d: Int, m: Int, y: Int): Int {
        val a = (14-m)/12; val yy=y+4800-a; val mm=m+12*a-3
        var x=d+(153*mm+2)/5+365*yy+yy/4-yy/100+yy/400-32045
        if (x < 2299161) x=d+(153*mm+2)/5+365*yy+yy/4-32083
        return x
    }
    private fun newMoon(k: Int): Double {
        val t=k/1236.85; val t2=t*t; val t3=t2*t
        val dr=Math.PI/180
        var jd=2415020.75933+29.53058868*k+0.0001178*t2-0.000000155*t3
        jd += 0.00033*kotlin.math.sin((166.56+132.87*t-0.009173*t2)*dr)
        val m=359.2242+29.10535608*k-0.0000333*t2-0.00000347*t3
        val mp=306.0253+385.81691806*k+0.0107306*t2+0.00001236*t3
        val f=21.2964+390.67050646*k-0.0016528*t2-0.00000239*t3
        var c=(0.1734-0.000393*t)*kotlin.math.sin(m*dr)+0.0021*kotlin.math.sin(2*m*dr)
        c-=0.4068*kotlin.math.sin(mp*dr); c+=0.0161*kotlin.math.sin(2*mp*dr)
        c-=0.0004*kotlin.math.sin(3*mp*dr); c+=0.0104*kotlin.math.sin(2*f*dr)
        c-=0.0051*kotlin.math.sin((m+mp)*dr); c-=0.0074*kotlin.math.sin((m-mp)*dr)
        c+=0.0004*kotlin.math.sin((2*f+m)*dr); c-=0.0004*kotlin.math.sin((2*f-m)*dr)
        c-=0.0006*kotlin.math.sin((2*f+mp)*dr); c+=0.0010*kotlin.math.sin((2*f-mp)*dr)
        c+=0.0005*kotlin.math.sin((2*mp+m)*dr)
        val delta=if(t < -11) 0.001+0.000839*t+0.0002261*t2-0.00000845*t3-0.000000081*t*t3 else -0.000278+0.000265*t+0.000262*t2
        return jd+c-delta
    }
    private fun sunLongitude(jdn: Double): Int {
        val t=(jdn-2451545.0)/36525; val t2=t*t; val dr=Math.PI/180
        val m=357.52910+35999.05030*t-0.0001559*t2-0.00000048*t*t2
        val l0=280.46645+36000.76983*t+0.0003032*t2
        var dl=(1.914600-0.004817*t-0.000014*t2)*kotlin.math.sin(dr*m)
        dl+=(0.019993-0.000101*t)*kotlin.math.sin(2*dr*m)+0.000290*kotlin.math.sin(3*dr*m)
        var l=(l0+dl)*dr; l-=Math.PI*2*floor(l/(Math.PI*2))
        return floor(l/(Math.PI*2)*12).toInt()
    }
    private fun month11(y: Int): Int {
        val off=jd(31,12,y)-2415021
        val k=floor(off/29.530588853).toInt()
        var nm=floor(newMoon(k)+0.5+7.0/24).toInt()
        if(sunLongitude(nm.toDouble())>=9) nm=floor(newMoon(k-1)+0.5+7.0/24).toInt()
        return nm
    }
    private fun leapOffset(a11: Int): Int {
        val k=floor(0.5+(a11-2415021.076998695)/29.530588853).toInt()
        var i=1; var last=0; var arc=sunLongitude(floor(newMoon(k+i)+0.5+7.0/24))
        do {
            last=arc; i++; arc=sunLongitude(floor(newMoon(k+i)+0.5+7.0/24))
        } while(arc!=last && i<14)
        return i-1
    }
    private fun lunar(dd: Int, mm: Int, yy: Int): Lunar {
        val day=jd(dd,mm,yy); val k=floor((day-2415021.076998695)/29.530588853).toInt()
        var nm=floor(newMoon(k)+0.5+7.0/24).toInt()
        if(nm>day) nm=floor(newMoon(k-1)+0.5+7.0/24).toInt()
        val a11=month11(yy); val b11=if(a11>=nm) month11(yy-1) else month11(yy+1)
        val lunarDay=day-nm+1
        val diff=floor((nm-a11)/29.0).toInt()
        var lunarMonth=diff+11; var lunarYear=if(a11>=nm) yy else yy+1; var leap=false
        if(b11-a11>365) {
            val leapDiff=leapOffset(a11)
            if(diff>=leapDiff) { lunarMonth=diff+10; if(diff==leapDiff) leap=true }
        }
        if(lunarMonth>12) lunarMonth-=12
        if(lunarMonth>=11 && diff<4) lunarYear--
        return Lunar(lunarDay,lunarMonth,lunarYear,leap)
    }
    private data class Lunar(val day:Int,val month:Int,val year:Int,val leap:Boolean)
}
