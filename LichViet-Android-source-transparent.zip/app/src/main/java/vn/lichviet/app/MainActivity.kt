package vn.lichviet.app

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this).apply {
            text = "LỊCH VIỆT\n\nĐã cài ứng dụng lịch âm – dương.\n\nCách thêm widget:\n1. Nhấn giữ màn hình chính.\n2. Chọn Tiện ích (Widgets).\n3. Tìm “Lịch Việt”.\n4. Kéo widget ra màn hình.\n\nWidget chữ trắng, nền trong suốt."
            textSize = 18f
            setPadding(28, 36, 28, 28)
        }
        setContentView(tv)
    }
}
